﻿public interface IServicoMensagem
{
    void Envia(Mensagem msg);
}

public class Mensagem
{
    public string Destinatario { get; set; }
    public string? Titulo { get; set; }
    public string Corpo { get; set; }

    public Mensagem(string destinatario, string corpo, string? titulo = null)
    {
        Destinatario = destinatario;
        Titulo = titulo;
        Corpo = corpo;
    }
}

class Email : IServicoMensagem
{ 
    public void Envia(Mensagem msg)
    {
        Console.WriteLine($"[Email] Para: {msg.Destinatario}");
        Console.WriteLine($"Título: {msg.Titulo}");
        Console.WriteLine($"Corpo: {msg.Corpo}");
    }

    

}

class Sms : IServicoMensagem
{
    public void Envia(Mensagem msg)
    {
        Console.WriteLine($"[SMS] Para: {msg.Destinatario}");
        Console.WriteLine($"Corpo: {msg.Corpo}");
    }
}

class Push : IServicoMensagem
{
    public void Envia(Mensagem msg)
    {
        Console.WriteLine($"[Push] Para: {msg.Destinatario}");
        Console.WriteLine($"Título: {msg.Titulo}");
        Console.WriteLine($"Corpo: {msg.Corpo}");
    }
}

public abstract class MensagemTransport
{
    public void StartEnvio(Mensagem msg)
    {
        IServicoMensagem servico = CreateServico();
        servico.Envia(msg);
    }

    protected abstract IServicoMensagem CreateServico();
}


public class EmailCreator : MensagemTransport
{
    protected override IServicoMensagem CreateServico()
    {
        return new Email();
    }
}

public class SmsCreator : MensagemTransport
{
    protected override IServicoMensagem CreateServico()
    {
        return new Sms();
    }
}

public class PushCreator : MensagemTransport
{
    protected override IServicoMensagem CreateServico()
    {
        return new Push();
    }
}
class Program
{
    static void Main(string[] args)
    {
        MensagemTransport email = new EmailCreator();
        email.StartEnvio(new Mensagem("joao@email.com", "Bem-vindo ao sistema!", "Boas-vindas\n"));

        MensagemTransport sms = new SmsCreator();
        sms.StartEnvio(new Mensagem("11999999999", "Seu código é 1234\n"));

        MensagemTransport push = new PushCreator();
        push.StartEnvio(new Mensagem("user123", "Notificação recebida!", "Nova atividade"));
    }
}

