using System;

public interface IPaymentSystem
{
    void paypalPayment();
    void paypalReceive();
}

public class PayPal : IPaymentSystem
{
    public void paypalPayment()
    {
        Console.WriteLine("Realizando pagamento pelo PayPal.");
    }

    public void paypalReceive()
    {
        Console.WriteLine("Recebendo pagamento pelo PayPal.");
    }
}

public class Payoneer
{
    public void sendPayment()
    {
        Console.WriteLine("Realizando pagamento pelo Payoneer.");
    }

    public void receivePayment()
    {
        Console.WriteLine("Recebendo pagamento pelo Payoneer.");
    }
}

public class PayoneerAdapter : IPaymentSystem
{
    private readonly Payoneer payoneer;

    public PayoneerAdapter(Payoneer payoneer)
    {
        this.payoneer = payoneer;
    }

    public void paypalPayment()
    {
        payoneer.sendPayment();
    }

    public void paypalReceive()
    {
        payoneer.receivePayment();
    }
}

public class MercadoPago
{
    public void makePayment()
    {
        Console.WriteLine("Realizando pagamento pelo MercadoPago.");
    }

    public void acceptPayment()
    {
        Console.WriteLine("Recebendo pagamento pelo MercadoPago.");
    }
}

public class MercadoPagoAdapter : IPaymentSystem
{
    private readonly MercadoPago mercadoPago;

    public MercadoPagoAdapter(MercadoPago mercadoPago)
    {
        this.mercadoPago = mercadoPago;
    }

    public void paypalPayment()
    {
        mercadoPago.makePayment();
    }

    public void paypalReceive()
    {
        mercadoPago.acceptPayment();
    }
}

public class Client
{
    private IPaymentSystem paymentSystem;

    public Client(IPaymentSystem paymentSystem)
    {
        this.paymentSystem = paymentSystem;
    }

    public void MakeTransaction()
    {
        paymentSystem.paypalPayment();
        paymentSystem.paypalReceive();
    }
}

class Program
{
    static void Main(string[] args)
    {
        var paypal = new PayPal();
        var clientPayPal = new Client(paypal);
        Console.WriteLine("Transação com o PayPal:");
        clientPayPal.MakeTransaction();

        var payoneer = new Payoneer();
        var payoneerAdapter = new PayoneerAdapter(payoneer);
        var clientPayoneer = new Client(payoneerAdapter);
        Console.WriteLine("\nTransação com o Payoneer:");
        clientPayoneer.MakeTransaction();

        var mercadoPago = new MercadoPago();
        var mercadoPagoAdapter = new MercadoPagoAdapter(mercadoPago);
        var clientMercadoPago = new Client(mercadoPagoAdapter);
        Console.WriteLine("\nTransação com o MercadoPago:");
        clientMercadoPago.MakeTransaction();
    }
}