﻿public interface IVehicle
{
    void StartRoute();
    void GetCargo();
}

class Carro : IVehicle
{
    public void StartRoute()
    {
        Console.WriteLine("Carro: Começando Rota");
    }

    public void GetCargo()
    {
        Console.WriteLine("Carro: Pegando Carga");
    }

}

class Moto : IVehicle
{
    public void StartRoute()
    {
        Console.WriteLine("Moto: Começando Rota");
    }

    public void GetCargo()
    {
        Console.WriteLine("Moto: Carregando produtos");
    }
}

class Bicicleta : IVehicle
{
    public void StartRoute()
    {
        Console.WriteLine("Bicicleta: Começando Rota");
    }
    public void GetCargo()
    {
        Console.WriteLine("Bicicleta: Carregando carga pequena");
    }
}

public abstract class Transport
{
    public void StartTransport()
    {
        IVehicle vehicle = CreateTransport();
        vehicle.StartRoute();
        vehicle.GetCargo();
    }
    protected abstract IVehicle CreateTransport();
}

public class CarroCreator : Transport
{
    protected override IVehicle CreateTransport()
    {
        return new Carro();
    }
}

public class MotoCreator : Transport
{
    protected override IVehicle CreateTransport()
    {
        return new Moto();
    }

}

public class BicicletaCreator : Transport
{
    protected override IVehicle CreateTransport()
    {
        return new Bicicleta();
    }
}
class Program
{
    static void Main(string[] args)
    {
        Transport carroTransport = new CarroCreator();
        carroTransport.StartTransport();

        Transport motoTransport = new MotoCreator();
        motoTransport.StartTransport();

        Transport bicicletaTransport = new BicicletaCreator();
        bicicletaTransport.StartTransport();
    }
}

