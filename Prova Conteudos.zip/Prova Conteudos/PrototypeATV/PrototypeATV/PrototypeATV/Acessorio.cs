﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototypeATV
{
    public class Acessorio
    {
        public string nome;
        

        public Acessorio(string nome)
        {
            this.nome = nome;
        }
    }
}
