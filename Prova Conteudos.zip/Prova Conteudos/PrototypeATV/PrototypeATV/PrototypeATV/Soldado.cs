﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace PrototypeATV
{
     public  class Soldado
    {
        public string nome;
        public string arma;
        public Acessorio Acessorio;


        public Soldado ShallowCopy()
        {
            return (Soldado)MemberwiseClone();
        }

        public Soldado DeepCopy()
        {
            Soldado other = (Soldado)MemberwiseClone();
            other.Acessorio = new Acessorio(Acessorio.nome);
            return other;
        }

    }
}
