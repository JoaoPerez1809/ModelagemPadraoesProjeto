﻿using System.Runtime;
using System;
using PrototypeATV;
using System.Security.Cryptography.X509Certificates;

class Program
{
    static void Main()
    {
        Soldado soldado1 = new()
        {
            nome = "Soldado Ferido",
            arma = "AK-47",
            Acessorio = new Acessorio("Capacete")
        };

        Soldado soldado2 = soldado1.ShallowCopy();
        Soldado soldado3 = soldado1.ShallowCopy();
        Soldado soldado4 = soldado1.ShallowCopy();


        Console.WriteLine("Valores do soldado1, soldado2, soldado3 e soldado4:");
        Console.WriteLine("   soldado1 valores: ");
        ExibirSoldado(soldado1);
        Console.WriteLine("   soldado2 valores:");
        ExibirSoldado(soldado2);
        Console.WriteLine("   soldado3 valores: ");
        ExibirSoldado(soldado3);
        Console.WriteLine("   soldado4 valores:");
        ExibirSoldado(soldado4);
    }
        public static void ExibirSoldado(Soldado soldado)
    {
        Console.WriteLine($"      Nome: {soldado.nome:s}, Arma: {soldado.arma:d}");
        Console.WriteLine($"      Acessorio: {soldado.Acessorio.nome:d}");
    }
    
}
