public interface IVeiculo
{
    void LigaVeiculo();
}