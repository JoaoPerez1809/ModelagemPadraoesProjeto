public interface IVeiculoMoto : IVeiculo
{
    void ConfigureMoto(string cor, int ano, float motor);
}