public interface IVeiculoCarro : IVeiculo
{
    void ConfigureCarro(string cor, int ano, float motor,  int portas, int assentos);
}