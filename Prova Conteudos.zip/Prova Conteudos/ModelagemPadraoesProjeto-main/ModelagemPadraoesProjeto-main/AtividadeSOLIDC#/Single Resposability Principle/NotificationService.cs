using System;


class NotificationService
{
    public void NotifyClient()
    {
        Console.WriteLine("Notificação enviada para o cliente.");
    }
}