using System;

class ClientService
{
    public void CreateClient()
    {
        Console.WriteLine("Cliente criado.");
    }

    public void ReadClient()
    {
        Console.WriteLine("Detalhes do cliente.");
    }

    public void UpdateClient()
    {
        Console.WriteLine("Cliente atualizado.");
    }

    public void DeleteClient()
    {
        Console.WriteLine("Cliente removido.");
    }
}