public interface IPagamentoComRecompensa
{
    void AtualizarPontuacao(int valor);
}