using System.Data;
public abstract class Poligono
{
    public abstract double getArea();
    //COm abstract e override substitui os nomes na vez que forem necessários
    public abstract string getName();
}