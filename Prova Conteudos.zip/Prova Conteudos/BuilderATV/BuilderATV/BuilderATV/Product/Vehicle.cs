﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BuilderATV.Parts;

namespace BuilderATV.Product
{
    internal class Vehicle
    {
        private int seats;
        private Engine engine;
        private Transmission transmission;
        private VehicleType vehicleType;

        public void SetSeats(int seats) {  this.seats = seats; }
        public void SetEngine(Engine engine) { this.engine = engine; }
        public void SetTransmission(Transmission transmission) {  this.transmission = transmission; }
        public void SetVehicleType(VehicleType vehicleType) { this.vehicleType = vehicleType; }

        public void debugInfo()
        {
            Console.WriteLine("Assentos:" + seats + ", Motor:" + engine + ", Transmissão:" + transmission + ",Tipo do Veiculo:" + vehicleType);
        }
    }
}
