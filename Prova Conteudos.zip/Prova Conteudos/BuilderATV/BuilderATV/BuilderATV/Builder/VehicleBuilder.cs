﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BuilderATV.Parts;
using BuilderATV.Product;

namespace BuilderATV.Builder
{
    class VehicleBuilder : IBuilder
    {
        private Vehicle vehicle;
        public void Reset() { vehicle = new Vehicle(); }
        
        public void SetSeats(int seats) { vehicle.SetSeats(seats); }
        public void SetEngine(Engine engine) { vehicle.SetEngine(engine); }
        public void SetTransmission(Transmission transmission) { vehicle.SetTransmission(transmission); }
        public void SetVehicleType(VehicleType vehicleType) { vehicle.SetVehicleType(vehicleType); }
        public Vehicle GetVehicle() {
            Vehicle result = vehicle;
            Reset();
            return result; }
    }
}
