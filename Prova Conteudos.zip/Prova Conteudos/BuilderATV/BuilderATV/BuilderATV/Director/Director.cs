﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using BuilderATV.Builder;
using BuilderATV.Parts;
using BuilderATV.Product;

namespace BuilderATV.Director
{
    class Director
    {
        IBuilder builder;

        public Director(IBuilder builder)
        {
            this.builder = builder;
        }
        public void ConstructSedanCar()
        {
            builder.SetSeats(5);
            builder.SetEngine(new Engine(300));
            builder.SetTransmission(Transmission.AUTOMATIC);
            builder.SetVehicleType(VehicleType.SEDAN);
            
        }
        public void ConstructTruck()
        {
            builder.SetSeats(4);
            builder.SetEngine(new Engine(500));
            builder.SetTransmission(Transmission.MANUAL);
            builder.SetVehicleType(VehicleType.TRUCK);
        }

        public void ConstructSUV(VehicleBuilder builder)
        {
            builder.SetSeats(6);
            builder.SetEngine(new Engine(400));
            builder.SetTransmission(Transmission.AUTOMATIC_SEQUENTIAL);
            builder.SetVehicleType(VehicleType.SUV);
        }

    }
}
