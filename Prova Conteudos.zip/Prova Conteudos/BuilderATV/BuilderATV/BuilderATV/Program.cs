﻿using BuilderATV.Builder;
using BuilderATV.Director;
using BuilderATV.Product;

internal class Program
{
    private static void Main(string[] args)
    {
        
        
            VehicleBuilder builder = new VehicleBuilder();
            Director director = new Director(builder);
            director.ConstructSUV(builder);
            Vehicle vehicle = builder.GetVehicle();
            vehicle.debugInfo();
        
    }
}