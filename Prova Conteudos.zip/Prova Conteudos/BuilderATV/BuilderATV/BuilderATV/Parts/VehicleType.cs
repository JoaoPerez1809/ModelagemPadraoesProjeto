﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuilderATV.Parts
{
    enum VehicleType
    {
        SEDAN,
        SPORTCAR,
        PICKUPTRUCK,
        TRUCK,
        SUV
    }

}
