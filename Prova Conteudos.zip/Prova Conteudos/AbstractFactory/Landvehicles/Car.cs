class Car : ILandVehicle
{
    public void StartRoute()
    {
        GetCargo();
        Console.WriteLine("Carro: Começando Rota");
    }

    public void GetCargo()
    {
        Console.WriteLine("Carro: Pegando Carga");
    }

}