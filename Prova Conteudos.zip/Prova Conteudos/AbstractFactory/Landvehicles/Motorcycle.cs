class Motorcycle : ILandVehicle
{
    public void StartRoute()
    {
        GetCargo();
        Console.WriteLine("Moto: Começando Rota");
    }

    public void GetCargo()
    {
        Console.WriteLine("Moto: Carregando Produtos");
    }

}