class Scooter : ILandVehicle
{
    public void StartRoute()
    {
        GetCargo();
        Console.WriteLine("Scooter: Começando Rota");
    }

    public void GetCargo()
    {
        Console.WriteLine("Scooter: Carregando Produtos");
    }

}