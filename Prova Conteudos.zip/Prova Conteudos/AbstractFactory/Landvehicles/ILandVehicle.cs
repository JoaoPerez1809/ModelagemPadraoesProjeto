interface ILandVehicle
{
    void StartRoute();
    void GetCargo();
}