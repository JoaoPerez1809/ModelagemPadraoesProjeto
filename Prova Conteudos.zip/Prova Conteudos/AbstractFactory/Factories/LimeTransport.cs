class LimeTransport : ITransportFactory 
{ 
 public IAircraft CreateTransportAircraft() 
 { 
 return new Drone(); 
 } 
 public ILandVehicle CreateTransportVehicle() 
 { 
 return new Scooter(); 
 } 
} 