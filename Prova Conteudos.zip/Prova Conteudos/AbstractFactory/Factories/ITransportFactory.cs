interface ITransportFactory 
{ 
 IAircraft CreateTransportAircraft(); 
 ILandVehicle CreateTransportVehicle(); 
} 